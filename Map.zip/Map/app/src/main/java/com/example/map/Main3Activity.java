package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    private ImageView iv_photo;
    private TextView tv_nickName;
    private TextView tv_qm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        iv_photo = (ImageView)findViewById(R.id.iv_photo);
        tv_nickName = (TextView)findViewById(R.id.tv_nickName);
        tv_qm = (TextView)findViewById(R.id.tv_qm);
        int photo = getIntent().getIntExtra("photo",R.drawable.headimage01);
        iv_photo.setImageResource(photo);
        tv_nickName.setText(getIntent().getStringExtra("nickName"));
        tv_qm.setText(getIntent().getStringExtra("qm"));

    }
}
