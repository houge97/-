package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.util.EthiopicCalendar;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    private EditText et_nickName;
    private EditText et_qm ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        et_nickName = (EditText)findViewById(R.id.et_nickName);
        et_qm = (EditText)findViewById(R.id.et_qm);
    }
    public void doClick(View view){
//        把输入的值传到第一个页面 主页面
        Intent intent = new Intent();
//        判断输入的值是否为空
        if (TextUtils.isEmpty(et_nickName.getText().toString())){
            Toast.makeText(this, "昵称不能为空", Toast.LENGTH_SHORT).show();
            return;
            }
        if (TextUtils.isEmpty(et_qm.getText().toString())){
            Toast.makeText(this, "签名不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        intent.putExtra("nickName",et_nickName.getText().toString());
        intent.putExtra("qm",et_qm.getText().toString());

        setResult(RESULT_OK,intent);//设置结果码
        finish();
    }
}
