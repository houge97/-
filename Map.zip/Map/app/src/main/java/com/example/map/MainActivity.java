package com.example.map;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ListView listView;

    int [] photo = new int[]{
            R.drawable.headimage01,
            R.drawable.headimage02,
            R.drawable.headimage03,
            R.drawable.headimage04,
            R.drawable.headimage05,
            R.drawable.headimage06,
            R.drawable.headimage07,
            R.drawable.headimage08,
            R.drawable.headimage09,
            R.drawable.headimage10,
            R.drawable.headimage11,
            R.drawable.headimage12,
            R.drawable.headimage13,
            R.drawable.headimage14,
            R.drawable.headimage15,
            R.drawable.headimage16,
            R.drawable.headimage17,
            R.drawable.headimage18,
            R.drawable.headimage19,
            R.drawable.headimage20,
    };
     String[] nickNames = new String[]{
        "猴哥军团01",
                "猴哥军团02",
                "猴哥军团03",
                "猴哥军团04",
                "猴哥军团05",
                "猴哥军团06",
                "猴哥军团07",
                "猴哥军团08",
                "猴哥军团09",
                "猴哥军团10",
                "猴哥军团11",
                "猴哥军团12",
                "猴哥军团13",
                "猴哥军团14",
                "猴哥军团15",
                "猴哥军团16",
                "猴哥军团17",
                "猴哥军团18",
                "猴哥军团19",
                "猴哥军团20",
    };
     String []qms = new String[]{
             "我爱学习",
             "我爱Android",
             "我爱猴哥",
             "我是猴哥媳妇",
             "我是猴哥的后盾",
             "先学习java",
             "我在努力学习安卓",
             "相信自己",
             "我会成功的",
             "努力的人都是可爱的",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
             "我爱java",
     };
    private List<Map<String,Object>>  list;
    private SimpleAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView)findViewById(R.id.listView);
        adapter = new SimpleAdapter(MainActivity.this,
                getData(),
                R.layout.item_layout,
                new String []{"photo","nickName","qm"},
                new int []{R.id.iv_photo,R.id.tv_nickName,R.id.tv_qm});
        listView.setAdapter(adapter);

//        点击进行 显示在新的页面

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Map<String,Object> map = list.get(i);//先取到列表的控件 中的小控件 进行 把小列表项的数据存到map中

                int photo = (Integer) map.get("photo");
                String nickName = (String) map.get("nickName");
                String qm = (String) map.get("qm");
                Intent intent = new Intent(MainActivity.this,Main3Activity.class);
                intent.putExtra("photo",photo);//前面 name 相当于键的名称 后面 相当于 键值
                intent.putExtra("nickName",nickName);
                intent.putExtra("qm",qm);
                startActivity(intent);

            }
        });
       listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
           @Override
           public boolean onItemLongClick(AdapterView<?> adapterView, View view, final  int position, long l) {
              Map<String,Object> map = list.get(position);
              int photo = (int) map.get("photo");//键值对中的 键名称
              new AlertDialog.Builder(MainActivity.this)
                      .setTitle("你要删除数据了")
                      .setIcon(photo)
                      .setMessage("你确定要删除"+map.get("nickName")+"吗？")
                      .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                          @Override
                          public void onClick(DialogInterface dialogInterface, int i) {
                              list.remove(position);
                              adapter.notifyDataSetChanged();
                          }
                      })
                      .setNegativeButton("取消",null)
                      .show();



               return true;
           }
       });


    }

    public List<Map<String,Object>> getData() {
       list = new ArrayList<>();
        //模拟数据

        for (int i=0;i<photo.length;i++){
            Map<String,Object > map = new HashMap<>();//一组map需要放在循环里面
            map.put("photo",photo[i]);
            map.put("nickName",nickNames[i]);
            map.put("qm",qms[i]);
            list.add(map);
        }

        return list;
    }
    public void doClick(View view){
        //点击添加摁扭进行添加一个新的map放入list中 放入集合中
        //先跳转到新的界面
        Intent intent = new Intent(MainActivity.this,Main2Activity.class);
        //不用传值 只是需要添加一个新的map
        startActivityForResult(intent,100);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode==100&&resultCode==RESULT_OK){
            String nickName = data.getStringExtra("nickName");
            String qm = data.getStringExtra("qm");

            Map<String ,Object>map = new HashMap<>();
            map.put("photo",R.drawable.headimage01);
            map.put("nickName",nickName);
            map.put("qm",qm);
            list.add(0,map);
            adapter.notifyDataSetChanged();//更新ui

        }




        super.onActivityResult(requestCode, resultCode, data);
    }
}
